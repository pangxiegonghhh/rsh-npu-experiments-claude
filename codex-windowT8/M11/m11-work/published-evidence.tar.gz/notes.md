# M11 执行笔记

- 用户指定：https://github.com/pangxiegonghhh/rsh-npu-experiments-claude/tree/codex-window/codex-windowT8
- 本地起点：main；两份未跟踪论文 PDF，保留。
- 根 CLAUDE.md 已读；现有第一层结果、旧仓库目录不可改写。

## 设备接管
- 用户覆盖旧M8实例隔离限制，复用同一实例。平台4元/小时，启动后运行中。
- 容器 f295d978bae1，物理NPU1，PCI0000:01:00.0，NPU空闲。
- Jupyter终端可用，直接无认证API请求返回403，未尝试提取cookie或更改访问权限。
- Chrome上传工具要求扩展启用Allow access to file URLs；已向用户发出配置说明并等待。
- 剪贴板泛读被自动审核拒绝（可能暴露旧敏感内容），已放弃，未读剪贴板；改用页面可见信息与Jupyter终端。
- 新产物均在m11-work，资料包不改；远端仅新目录。
- CPU working-set审计发现随机大gap会使2GiB源池里的唯一有效行不足4倍L2；正式计时前改为seed固定的随机1/2行gap，保留不等间距，并逐格验证216格cold/hot容量。
