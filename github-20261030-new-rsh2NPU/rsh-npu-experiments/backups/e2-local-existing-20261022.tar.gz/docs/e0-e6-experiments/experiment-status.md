# E0—E6 实验状态与数据

更新日期：2026-10-22（北京时间）。本文件是持续追加的实验台账；原始日志、二进制输出、代码哈希和实例状态将在每阶段填入。**未填写的数据表示未测得，不等于零。**

| 实验 | 目的 | 状态 | 实例 | 结果入口 |
|---|---|---|---|---|
| E0 | Cube输入与装载契约 | **已完成，G3补证闭合** | 本轮实例状态见E1 | [G3总结](artifacts/e0-g3/20261022-r1/summary.md) |
| E1 | 四种编码语义 | **已完成：1988主例、720重复、9小样均通过** | 10月22日15:46确认已关机，累计2小时7分钟 | [E1总结](artifacts/e1/20261022-r1/summary.md)；E2当前状态见下一行 |
| E2 | AIV展开与交接 | **未完成：新构建成功，首个非空小样设备异常；发现TSCM实际经GM** | 20:24:01确认OFF，累计2小时24分钟 | [E2断点](artifacts/e2/20261022-r1/summary.md) |
| E3 | A 格式同条件对照 | 未开始 | 无 | — |
| E4 | B 聚集对照 | 未开始 | 无 | — |
| E5 | 包大小与流水 | 未开始 | 无 | — |
| E6 | 冻结真实窗口 | 未开始；缺冻结计划 | 无 | — |

## 2026-10-22当前：E2首轮未通过

本地1344项输入/C++验证、2304项调度模型已通过；设备新构建成功，U0调用完成，随后首个非空U16/N17/Bitmap/q1/单缓冲小样报MPU异常，bootstrap返回1。正式1344批次、长循环、重复与E3未启动。

安装包确认UB→TSCM接口依赖TPipe/KFC，实际UB→GM→L1；原“无GM直接片上”前提需要纠正。根因尚未由设备分层复现确认。恢复时实例已关机且GPU不足，临时无GPU回收。检查点已封存，5,849,507 B/11265成员；Chrome策略阻止下载，尚未本地验证。详见[E2完整断点](artifacts/e2/20261022-r1/summary.md)。

## 2026-10-22最新收尾：E1编码语义通过

用户授权执行E1；Dense16、DenseTail、Bitmap16、LocalIndex16四种编码各497主例全部通过。U=0/1/15/16/17/31/32/37/48/63，N=1/16/17/32/33/64；含1028项z=0…256的单tile诊断、960项正常窗口编码案例。24核心配置×3新进程×10次=720次重复逐次通过，另9设备小样通过，最大绝对误差0。

16类非法输入在aclInit前拒绝。正式driver PID2173结束，E1_RC=0；本地独立按原列累加FP64重放全部2717案例调用，42953成员哈希、实际ELF/两库哈希及本地/实际执行源码一致性通过。

| 收尾项 | 结果/入口 |
|---|---|
| 设备结果 | [summary.json](artifacts/e1/20261022-r1/device/summary.json) |
| 完整分析与限制 | [E1总结](artifacts/e1/20261022-r1/summary.md) |
| 独立回放 | [local-replay-independent.json](artifacts/e1/20261022-r1/local-replay-independent.json) |
| 归档 | 9,051,185 B，42954成员；SHA-256 d0b6ccffac78f66deca5e721b4d32a18f622e86c2cfe9c07fe0e657de8cec3ac |
| 关机 | 2026-10-22 15:46:26北京时间观察确认已关机、开关off，累计2小时7分钟；[截图](artifacts/e1/20261022-r1/instance-off.png) |
| 下一步 | E2片上展开与跨核交接，未开始；见[续跑指针](resume.md) |

本轮采用AIV展开→GM→同步→AIC的语义路径，包含GM中转；不证明共享L1交接、双缓冲或性能收益。首次余额不足由用户充值解决；输入JSON键序差异经规范化字段和逐bin哈希核验一致；HTTP下载由用户亲自保留。原失败日志保留，未放宽验收。

下方G3及E0历史收尾中的“下一项E1/未开始”等均为当时断点，当前以本节和顶部表格为准。

## 2026-10-22历史收尾：G3闭合，E0收口

**不需要再补G3，可以进入E1编码语义验证；E1尚未启动。** D1是E0-S2内部已经完成的单入口独立target诊断，不是下一阶段。

| 本轮结果 | 数量/结论 |
|---|---|
| 固定物理A参照下的独立B选择器 | 144/144 PASS，完整多K、多N、两布局、逐/多分形及标签组合 |
| 已确认B支撑的正常A选择器 | 24/24 PASS |
| 锚定和常规/直装控制 | 1+4 PASS |
| 两种B布局K48/N64逐次重复 | 6进程、60调用 PASS |
| 合计 | 179进程、233调用，全PASS，最大绝对误差0 |
| 本地独立核验 | 170参考、144物理单位基、233原始输出/debug通过；716份调用后输入及guard核对通过 |
| 来源与归档 | 6个实际旧ELF与父检查点一致；2932成员哈希通过；归档2933成员逐字节与本地一致 |
| 关机 | 2026-10-22 15:08:47北京时间观察到已关机，累计1小时51分钟 |

固定A原始物理字节和逐分形直装参数，使B的K置换不能再与A候选loader抵消；B确认后再验证A，原G3独立性缺口已闭合。源码/原产物/SDK头对应未变，本轮同910B2/CANN9.0.0，物理卡由4变6并已单独记录，没有因此发现整轮重跑的必要性。

详见[G3总结](artifacts/e0-g3/20261022-r1/summary.md)、[设备汇总](artifacts/e0-g3/20261022-r1/device/summary.json)、[本地回放](artifacts/e0-g3/20261022-r1/local-replay.json)、[关机截图](artifacts/e0-g3/20261022-r1/instance-off-confirmed.png)。完整归档SHA-256为6b9fd44349c4988fe63e2b8d124519533a35932a0c379b638cbacbbdf7693eff，1,590,804字节。

原失败和复审历史保留。下方“需要补G3/正在执行/已关机”等陈述属于其所标日期和阶段，以本节及[续跑指针](resume.md)为当前状态。G3不替代E1编码、E2交接及后续性能/真实窗口实验。

## 2026-10-22复审历史：需要补G3独立参照（已由上述定向补测解决）

**撤回“全部门槛已闭合”的判断；现有数值结果保留。** 普通A/B选择器同时经过普通装载链，无法排除共同K置换抵消。已用原始输入在本地验证反例：A有2槽、B有128槽改变而输出误差仍为0。现有直装对照每次Mmad均K16，未独立约束一次多K装载。依据、原始文件及门槛逐项判断见[复审笔记](notes.md#2026-10-22结果复审g3独立布局证据尚未闭合)。这不是设备数值失败，也不是新增研究范围，而是原补测计划§6.2尚未充分实现。

建议下一轮固定预排布物理单位基A的直装路径，重用144个B-selector建立独立参照，并对两种B布局核心各做3进程×10次逐次复核。原24个A-selector和其他结果是否沿用，以源码、参数、工具链的对应关系及改动范围决定。**E1仍未开始，续跑先补G3。** 本轮没有启动实例或执行设备测试。

本地记录问题另行注明：现存254组probe输出/debug编号已核实完整，但检查器尚未自动强制数量匹配；地址区间本地推导成立，应补参数索引。两份归档的SHA/成员哈希通过，但原执行文件/库未归档，只有产物哈希；不能称“原二进制已回收”。这些不单独要求重跑设备。

## E0补测结论：2026-10-21晚间历史收尾（独立布局判定已由上方复审修正）

**E0已通过；下一步为E1，尚未开始。** 本结论覆盖当前910B2 / CANN9.0.0上的稠密操作数供给、紧凑尾部装载原语、有限合成尺寸及边界；不包含压缩编码性能、AIV→AIC跨核交接或真实窗口收益。

完整逐项结果见[补测总结](artifacts/e0-supplement/20261021-r1/summary.md)，可检索数据见[223项CSV](artifacts/e0-supplement/20261021-r1/device/results-final.csv)和[最终汇总JSON](artifacts/e0-supplement/20261021-r1/device/summary-final.json)。

| 检查 | 最终设备结果 | 证据 |
|---|---|---|
| 干净构建的独立用例 | **223/223通过，最大绝对误差0**；4项写回、171项布局/映射、39项尾部、5项逻辑尺寸、4项装载控制 | [主批次检查](artifacts/e0-supplement/20261021-r1/device/results/normal-final/checks.json) |
| 直装扩展 | M16/U16/N16、U32/N33、U48/N64、U17/N17，**4/4通过** | [直装检查](artifacts/e0-supplement/20261021-r1/device/results/direct-expanded-final/checks.json) |
| 完整集成路径 | 常规和直装**各17/17通过**：首轮16形状＋U17/U37相邻窗口；完整packed、最终输出及GM guard均检查 | [常规](artifacts/e0-supplement/20261021-r1/device/results/integrated-normal-final/results.json)、[直装](artifacts/e0-supplement/20261021-r1/device/results/integrated-direct-final/results.json) |
| 3个新进程的状态复核 | 7个核心配置各3进程，每进程10次，独立轮换A/B符号；**21组、210次通过** | [重复与扰动检查](artifacts/e0-supplement/20261021-r1/device/checks-final.json) |
| 合法分配内的有限哨兵扰动 | 6组通过；实际guard从0x5a改为0x36，原始字节和host元数据均已复核 | 同上；[归档回收信息](artifacts/e0-supplement/20261021-r1/transfer-info.json) |
| 集成状态复核 | M30分解和相邻窗口，3个新进程，每组含10次测量循环，逐组通过 | [进程0](artifacts/e0-supplement/20261021-r1/device/results/final-integrated-repeat-0/results.json)、[进程1](artifacts/e0-supplement/20261021-r1/device/results/final-integrated-repeat-1/results.json)、[进程2](artifacts/e0-supplement/20261021-r1/device/results/final-integrated-repeat-2/results.json) |
| 集成逐次覆盖补齐 | 常规/直装各3进程，每进程2案例×10次，独立轮换A/B；**120次逐次验算/保存全部通过**，每次完整packed/输出/padding/guard检查 | [逐次汇总](artifacts/e0-supplement/20261021-r1/each-call/summary.json)、[120条记录](artifacts/e0-supplement/20261021-r1/each-call/checks.json)、[本地逐次重放](artifacts/e0-supplement/20261021-r1/each-call-local-verification.json) |
| 非法参数拒绝 | 负B行索引、非16倍数的物理M，在host提交设备前拒绝，**2/2符合预期** | [拒绝记录](artifacts/e0-supplement/20261021-r1/device/host-rejection.json) |
| 本地复核 | 重算223份FP64参考，重放223＋27份捕获结果，核对两路径34个集成配置的正负B原始输出，全部一致 | [本地重放记录](artifacts/e0-supplement/20261021-r1/local-output-replay.json) |

### 实测资源与证据范围

| 存储区 | GetCoreMemSize返回值（B） | 独立用例最大显式数组（B） |
|---|---:|---:|
| L1 | **524032** | 12800（A＋B合计） |
| L0A | 65536 | 5120 |
| L0B | 65536 | 7680 |
| L0C | 131072 | 6144 |
| UB | 196352 | 独立AIC未显式分配；集成restore每AIV为1024 |

查询初始化和SoC查询返回0，检测SoC为Ascend910B2，见[原始容量输出](artifacts/e0-supplement/20261021-r1/device/resources.txt)、[结构化资源](artifacts/e0-supplement/20261021-r1/device/resources.json)。**此前进度消息及早期笔记把L1误读成524288，本表以原始524032为准。** 不据此推断框架预留或可分配上限；当前组合由实际构建/执行验证能容纳。地址证据为分配器契约、合法偏移枚举和设备选择器观察，未冒称L0原始字节读回。

### 修复与失败记录

1. 同源文件双入口诊断中，normal输出保留初始化标记12345、debug计数为0；direct入口通过。拆成独立编译单元后两个入口均通过。生产入口已拆为`npu/cube.cpp`与`npu/cube_direct.cpp`；这是本工具链产物的对照结果，不泛化为所有CANN多入口都不支持。
2. 直装在多K循环/集成路径曾出现数值错误。增加`M_MTE2`复用约束及`MTE2_M`就绪约束后，独立扩展、完整集成和最终重复复核全部通过。两组事件作为整体修复，未单独消融哪一组是唯一原因。
3. 上传包mtime=0导致增量构建沿用旧host；A轮换复核检出了源码/产物不一致。最终使用全新`build-final`与`integrated-final`，重跑全部223项及后续检查，确认实际host包含guard元数据和A/B轮换。早期失败结果没有覆盖，均留在归档。
4. 容量查询先遇到logging链接库和C++ ABI问题，使用`-lunified_dlog`与`-D_GLIBCXX_USE_CXX11_ABI=0`解决；一次从Notebook启动的子进程缺NumPy，随后使用已核验的`/usr/local/python3.11.15/bin/python`（NumPy2.4.4）执行。完整日志已回收。

首轮507000缺完整原始构建上下文，本轮没有把它唯一归因于某条历史指令；当前直装方案的可用性由最终正确性和边界证据成立。

### G0—G6收口与归档

G0环境/干净构建、G1资源/地址/检查器、G2装载路径、G3独立布局、G4尾部/边界、G5真实逻辑尺寸、G6回归/备份/关机均通过。真正单次`Mmad(30,70,40)`的设备debug为`[1,30,70,40]`；采用零填充输入，有效区通过，不承诺未定义无效输出的数值。guard只证明本例保护区未被写坏；读范围另由地址审计和有限哨兵扰动支持。

- [完整原始归档](artifacts/e0-supplement/20261021-r1/e0-evidence-final.tar.gz)：1,415,323 B，SHA-256 `4f209a7ea54481c46cd563af599a5708d57e3b0ce4fadf4167c03e666491622d`，与远端一致。
- 归档含7442个文件，校验清单覆盖其余7441个；本地全部通过。29份实际源码/依赖与当前项目一致，另8份AppleDouble元数据随归档保留，未作为编译源码。[本地传输核验](artifacts/e0-supplement/20261021-r1/local-transfer-verification.json)
- [源码/产物检查点](artifacts/e0-supplement/20261021-r1/device/manifest-checkpoint.json)、[SDK头文件哈希](artifacts/e0-supplement/20261021-r1/device/sdk-header-hashes.json)、[最终命令](artifacts/e0-supplement/20261021-r1/device/commands-final.json)、[构建与全量执行脚本](artifacts/e0-supplement/20261021-r1/device/run-final.sh)均已保存；失败版源码包和日志也在归档中。
- 实例`BSMUOI9QAL6YDC4U`已关机、开关0、GPU释放，平台累计运行1小时4分钟（含首轮16分钟）。[本轮关机截图](artifacts/e0-supplement/20261021-r1/instance-off-final.png)，SHA-256 `cb9252a13491360bb255f0548cb23ef2f14481c265a3dd8e81e38577c111310b`。远端磁盘临时保留，不再依赖其作为证据。

**收尾审计与最终关机补充：** 上述1小时4分钟截图为主轮首次关机。审计发现旧集成runner只在首尾验证，不能覆盖计划要求的每次中间调用，因此恢复同一实例，用新host入口复用原kernel与固定输入，补齐120次逐次检查；父版本源码/二进制及SDK头文件均核对未变。全部数据本地重放通过后再次关机。[最终关机截图](artifacts/e0-supplement/20261021-r1/instance-off-each-call.png)保存于2026-10-21 21:58:49北京时间，显示**已关机、开关0、GPU释放，累计1小时27分钟**。这是10月21日的历史关机状态；当前状态见最上方G3收尾记录。

[逐次补充归档](artifacts/e0-supplement/20261021-r1/e0-each-call-followup.tar.gz)：98195 B，SHA-256 `fb4a87e09bf1e2ef02f58121be7aeec739ef04467588053995d9636e7bc0ca15`，与远端终端显示一致；265文件含哈希清单，其中其余264个均已校验。每次原始输出单独保存，没有用主轮首尾数据替代中间调用。[覆盖审计说明](artifacts/e0-supplement/20261021-r1/completion-audit-followup.md)

下面保留设计轮与首轮的历史状态，不能把当时“未执行/未完成”误认为当前断点。

### 2026-10-21 补测方案更新（设计轮历史，没有新增设备数据）

已将 [E0补测细则](e0-supplement-plan.md) 纳入[研究报告§7.1](../window-format-research-20261021/report.md)。本次只设计并修改文档，未操作实例、未修改实验源码、未编译或运行补测。下表为待办，不是通过记录；实例状态沿用首轮关机证据，本次未实时查询控制台。

| 子步骤 | 内容 | 当前状态 |
|---|---|---|
| E0-S0 | 环境/源码/输入/构建证据恢复 | 方案完成，未执行 |
| E0-S1 | 检查器、资源、地址与分配预算 | 方案完成，未执行 |
| E0-S2 | 直装的单入口/双入口/集成分层诊断 | 方案完成；首轮失败仍未定位 |
| E0-S3 | A/B独立布局、B两种暂存、列映射和写回 | 方案完成，未执行 |
| E0-S4 | M/K/N尾部、紧凑装载原语、相邻窗口、guard/读范围 | 方案完成，未执行 |
| E0-S5 | 多K消费及真正单次Mmad(30,70,40) | 方案完成，未执行 |
| E0-S6 | 回归、更新契约、归档和关机核验 | 方案完成，未执行 |

## E0：首轮输入契约微测（历史记录）

### 补测过程中的检查点（历史记录）

用户已授权按计划执行。原实例恢复运行，仍为910B2 / CANN9.0.0；新增独立微测和带guard的集成runner。独立常规及直装单入口最小例均通过；同源双入口产物的常规入口未更新输出和debug，待拆分编译单元对照确认。203个独立用例正在执行，不能预记全部通过。本轮完整结果尚未回收，结束状态以随后收尾记录为准；本段不覆盖首轮数据。

### 租用与环境

| 项目 | 状态／数据 |
|---|---|
| 市场 | [模力方舟算力市场](https://ai.gitee.com/compute)，当前登录用户 `user_3674` |
| 已选配置 | `dengjia-ascend910b-node02`，单张 Ascend 910B2、64 GB 显存、昆鹏 920/12核、64 GB 内存、100 GB 数据盘；按量 ¥4.00/小时；基础镜像 PyTorch 2.10 / Python 3.11 / CANN 9.0.0 |
| 订单状态 | 用户 2026-10-21 回复“已付款，已开机”；控制台核实实例运行中、按量计费。 |
| 实例 ID、创建时间 | `BSMUOI9QAL6YDC4U`，控制台显示 2026-10-21 14:56（北京时间） |
| SoC 与 CANN 精确版本 | `npu-smi` 显示 910B2；`ASCEND_HOME_PATH=/usr/local/Ascend/cann-9.0.0`；镜像选择 PyTorch 2.10 / Python 3.11 / CANN 9.0.0 |
| 编译器、驱动、Python 版本 | CMake 检测 GNU C++ 12.3.1；`npu-smi` 26.1.1；Python 3.11.15；目标 CANN `compiler/version.info` 为 9.0.0，见[环境原始记录](artifacts/e0-device/e0-environment.txt) |
| L1/L0A/L0B/L0C/UB 容量 | 待 `GetCoreMemSize` 查询 |
| 实例关闭时间与控制台证据 | 2026-10-21 约 15:12（北京时间），控制台显示“已关机”、开关为 0，累计运行 16 分钟；见[关机截图](artifacts/e0-device/instance-off.png)。页面说明关机后磁盘保留约 36 小时，不把远端磁盘作为长期证据。 |

### 微测矩阵

| 检查 | 计划输入 | 实测状态 | 数值结果/日志 |
|---|---|---|---|
| K 分形和累加 | W16，压缩 K=16/32/48，N=16/32/64，原始 B 行号 `3j+1` | **9/9 通过** | 当前 V1 的单 K16 连续累加路径，最大绝对误差 0；[原始结果](artifacts/e0-device/e0-all.json) |
| N 尾部 | W16，压缩 K=16/32/48，N=17/33 | **6/6 有效列通过** | 最大绝对误差 0；未单独检查 N padding 的写回与越界 |
| 官方非整倍数示例 | M=30，K=70，N=40 | **仅做替代案例** | 已测 30 行、70 个压缩列、N40，但使用两个 W16 窗口与逐 K16 Mmad；不是单次逻辑 `Mmad(m=30,k=70,n=40)` 的官方案例；有效输出误差 0 |
| A 在 L1 中的单窗口排列 | 逐K16与多K16，A2的ZZ顺序 | **逐 K16 路径通过** | 输入 `[k_tile,16,16]`；没有独立读回 A1/A2 或验证一次多 K16 Load2D |
| B 的整块NZ与逐K16暂存 | 分形内转置到B2的ZN | **当前逐K16暂存路径间接通过** | 跨距为3的原始 B 行映射全部数值正确；整块 NZ 和 B2 的独立字节级验证未做 |
| 装载路径 | GM→L1→L0；预排布A的GM→L0可行性 | **常规路径通过；直装路径失败待诊断** | GM→A1→A2 的 16 组通过。直装 A 在目标 9.0.0 编译通过，但单例运行 `LaunchAscendKernel ret 507000`、输出错误；[原始日志](artifacts/e0-device/e0-direct-first.log)。同次重编译后常规路径仍通过。不能据此断言硬件不支持 GM→L0。 |
| 地址与资源 | A2/B2的512 B起点、CO1的256元素起点；平台容量 | **未完成** | 本轮没读到 `PlatformAscendC::GetCoreMemSize` 的目标值，地址/guard检查未完成。补测按S1做合法地址检查与host非法参数拒绝，不向设备提交故意错位访问 |

### 结果与判定

E0 首轮设备结果：常规 V1 Cube 路径的 15 组 W16/K16×N 组合和 1 组 M30/压缩K70/N40 替代案例，**16/16 有效输出通过，最大绝对误差 0**。这些值是端到端带同步的主机调用结果，不是纯 kernel 延迟。直接 GM→L0A 试验在首例失败；资源、padding guard、独立字节布局和真正的非整倍数逻辑 Mmad 尚未测完。因此 E0 仍为待补测，**E1 不得启动**。本地先前的 CPU 格式研究通过1988项语义检查与20项布局检查，见[研究阶段结果](../window-format-research-20261021/probe-results.json)；那不是E0设备结论。

| M | 压缩K | 原矩阵K | N | W16窗口 | K16总块数 | 最大绝对误差 |
|---:|---:|---:|---:|---:|---:|---:|
| 16 | 16 | 47 | 16 | 1 | 1 | 0 |
| 16 | 16 | 47 | 17 | 1 | 1 | 0 |
| 16 | 16 | 47 | 32 | 1 | 1 | 0 |
| 16 | 16 | 47 | 33 | 1 | 1 | 0 |
| 16 | 16 | 47 | 64 | 1 | 1 | 0 |
| 16 | 32 | 95 | 16 | 1 | 2 | 0 |
| 16 | 32 | 95 | 17 | 1 | 2 | 0 |
| 16 | 32 | 95 | 32 | 1 | 2 | 0 |
| 16 | 32 | 95 | 33 | 1 | 2 | 0 |
| 16 | 32 | 95 | 64 | 1 | 2 | 0 |
| 16 | 48 | 143 | 16 | 1 | 3 | 0 |
| 16 | 48 | 143 | 17 | 1 | 3 | 0 |
| 16 | 48 | 143 | 32 | 1 | 3 | 0 |
| 16 | 48 | 143 | 33 | 1 | 3 | 0 |
| 16 | 48 | 143 | 64 | 1 | 3 | 0 |
| 30 | 70 | 209 | 40 | 2 | 10 | 0 |

原始 B 行映射为 `global_col=3*local_col+1`，因此表中“原矩阵K”大于压缩K。最后一行是两个 W16 窗口拼接的替代案例，其 `K16总块数=10` 是每窗口5块的总和。

结束门槛：目标环境编译可复现；所有必选尺寸的设备输出逐元素与CPU参考比对并报告最大误差；写回尾部、padding及guard未越界；资源/地址要求记录。若任一项不满足，E0标记失败或待续，不进入E1。结束前备份本地可用日志与结果并核验，关闭实例。

上述门槛由[补测计划§10](e0-supplement-plan.md)具体化为G0～G6：padding区和guard分开判定，guard不变不能证明无越界读；直装须取得正确性通过或有明确目标依据的不适用结论。未定位启动错误仍保留待补测，当前没有任何新增门槛已通过。

### 原始证据清单

| 文件/页面 | SHA-256 或页面可见状态 | 说明 |
|---|---|---|
| [基线源码与输入归档](artifacts/e0-device/rsh-e0-baseline-inputs.tar.gz) | SHA-256 `abe16cd02095039470ed1e880e87a312cf37f488f4add93e2d272de452c30476`，与远端一致 | `npu/`、16组 E0 输入与 manifest；设备路径 `/data/e0-run` |
| [直装修改源码归档](artifacts/e0-device/rsh-e0-direct-src.tar.gz) | SHA-256 `760cb35eb16ac9446370ef804d923111e518b0cd9fc1db8c076b1c14badd7802`，与远端一致 | 只用于 E0 直装路径；代码修改仍在当前新项目 `npu/` |
| 构建日志 | CMake 配置返回 0；基线和直装修改均构建返回 0；远端日志曾在 `/data/e0-{configure,build,direct-build}.log` | 完整构建日志未回收到本地；直装修改构建显示 clock-skew 警告，下一轮应复查产物哈希 |
| [环境查询](artifacts/e0-device/e0-environment.txt) | 目标 910B2，CANN 9.0.0，`npu-smi` 26.1.1 | L1/L0/UB 容量仍未查询 |
| [16组设备原始结果](artifacts/e0-device/e0-all.json) | SHA-256 `145542978e600384da3220b8757a565411694a96141cc5689ebd10c693bf0ce9` | `correctness=true`，每组 `max_abs_error=0`；其中 `k` 字段是原矩阵列数 47/95/143/209，压缩 K 见 case 名及 manifest |
| [直装失败原始日志](artifacts/e0-device/e0-direct-first.log) | `RegisterAscendBinary aic ret 107000`、`LaunchAscendKernel ret 507000` | 常规路径重编译后同样打印前者但可通过；失败归因需后续隔离 |
| [控制台已关机截图](artifacts/e0-device/instance-off.png) | 实例 `BSMUOI9QAL6YDC4U` 显示“已关机” | 本轮停止计费核对 |

2026-10-22 E2回收补记：用户确认“无法下载”。Chrome拦截未解决，远端检查点未本地回收；实例保持OFF。下一次优先核对远端保留状态与平台允许的安全备份方式。
