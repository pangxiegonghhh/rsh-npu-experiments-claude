# 实验中断与续跑指针

**本地备份追加任务：用户已设置SSH密码，但平台和用户均未看到SSH命令；未找到导出入口，申请公网端口提示仅包周期可用。SCP未能连接。临时无GPU实例已再次确认OFF、累计2小时34分钟，截图backup-instance-off.png。本地现有E2材料正在独立打包，远端新增二进制/日志仍未回收。**

**当前活动实验：E2未完成。设备新构建成功，但首个非空小样报MPU地址异常，正式批次/双缓冲/长循环未启动。恢复时原实例已OFF、GPU不足，无GPU回收后于20:24:01确认再次OFF、累计2小时24分钟；截图见E2总结。关键新发现：当前SDK的UB→TSCM实际经GM/KFC，不能按无GM片上路径验收。远端检查点已封存，Chrome拦截归档下载，用户已确认无法下载；仍仅远端保存，尚未本地校验。下一次先回收/校验检查点，再修正通路与分层诊断。不要启动E3或重跑原失败bootstrap。**


**历史E1结束位置：2026-10-22 E1已完成。1988主例、720重复调用及9设备小样全部通过，本地独立重放2717次与42953文件哈希通过；实例已确认关机。下一项E2尚未开始。不要重新启动E1 driver。**

## 当前可信入口

- [E2首轮失败与通路核对](artifacts/e2/20261022-r1/summary.md)。远端/data/e2-20261022-r1保留，checkpoint归档SHA见总结；未独立重放。

- [E1完整总结](artifacts/e1/20261022-r1/summary.md)、[实验台账](experiment-status.md)、[研究计划§7](../window-format-research-20261021/report.md)、[输入契约](../window-format-research-20261021/cube-input-contract.md)。
- [E1设备汇总](artifacts/e1/20261022-r1/device/summary.json)、[独立本地重放](artifacts/e1/20261022-r1/local-replay-independent.json)、[收尾审计](artifacts/e1/20261022-r1/completion-audit.json)。
- 本轮实现：npu/e1_probe/、scripts/e1_experiment.py、scripts/e1_replay_independent.py。实际执行源码与二进制另封存在device目录，不能用后续改动覆盖它们。

## 实例与备份

实例BSMUOI9QAL6YDC4U，2026-10-22 15:46:26北京时间控制台观察到已关机、开关off、GPU释放，累计运行2小时7分钟。[关机截图](artifacts/e1/20261022-r1/instance-off.png)。观察时间不等于实际关机时刻；本轮E1前累计1小时51分钟。

- [E1完整归档](artifacts/e1/20261022-r1/e1-20261022-r1-closed.tar.gz)：9,051,185字节，42954成员（含哈希清单）。
- SHA-256：d0b6ccffac78f66deca5e721b4d32a18f622e86c2cfe9c07fe0e657de8cec3ac。
- 本地解包目录artifacts/e1/20261022-r1/device/含全部输入、每次A/refs/C/debug、guard、原始ELF/库、CMake构建/失败日志与环境。
- 远端/data/e1-20261022-r1的正式driver PID2173已结束，driver.rc=E1_RC=0。bootstrap初次在JSON字面SHA检查处退出1，随后规范化内容核验一致后成功构建；不重新运行prepare覆盖原输入。
- 远端磁盘仅临时保留，恢复不依赖远端残留。下次仍核对真实状态、SoC/SDK/设备映射，不沿用物理卡号假设。

## 已闭合的技术问题与边界

E0的G3独立参照缺口已闭合：[G3总结](artifacts/e0-g3/20261022-r1/summary.md)。固定物理A→独立B144→正常A24，另60次重复，全部233调用通过；原始归档SHA为6b9fd44349c4988fe63e2b8d124519533a35932a0c379b638cbacbbdf7693eff。原E0主轮223例、两路径各17集成、216次重复与120次逐次集成证据保留。

E1四种格式的还原A、原列映射、尾部和Cube结果通过；U0无descriptor并由设备显式产生零输出。主批次四种编码各497例，共960正常窗口编码案例和1028单tile占用率诊断。后者允许固定结构列域有零值，不作为真实列并集分布。

E1是AIV解码→GM→host同步→AIC的语义诊断路径；没有验证共享L1、跨核ready/release、双缓冲流水或性能收益。原A重排、行窗口、路由和Residual归属保持不变。

## E2原启动步骤（历史；当前断点见顶部与E2总结）

1. 阅读研究报告§5.3和§7的E2定义、输入契约的跨核边界，以及E1总结/实际解码器。将编码语义基线与新的交接逻辑分开追溯。
2. 先实现Bitmap16/LocalIndex16的单缓冲、无重叠片上展开与共享L1消费，固定输出所有权；共同tiling导出共享地址，不能各核独立分配后假定地址一致。
3. 验证UB→L1实际路径、ready/release配对、资源预算与长循环逐次输出。覆盖q=1/2/4/8、奇数/末包、首包/末包、空闲AIV按同一同步协议参与，先关闭Residual。
4. 单缓冲正确后再做双缓冲；每个槽消费完才复用。与E1含GM中转的正确性对照保持相同A/B、列映射及FP64参考。
5. 本地先完成参数、地址、计数和输入检查，目标设备使用新构建目录，核验实际源码/产物哈希和SDK版本。若新租卡仍在付款页交给用户；已有实例恢复前确认状态。
6. 每次调用保存结果/关键中间量/debug/guard，检查数量和连续编号；完成后回收原始证据、本地重放、更新台账和本文件并关机。只做E2，不自动执行E3。

## 后续依赖

E3—E5负责完整供给成本、B聚集、包长/计算粒度/流水和性能，不能用E1正确性排出格式优劣。E6前仍须恢复历史order/routing/rowmap并核验哈希；不临时重排行或重新分流冒充冻结窗口。

历史证据：[E0原补测总结](artifacts/e0-supplement/20261021-r1/summary.md)、[120次逐次集成补充](artifacts/e0-supplement/20261021-r1/completion-audit-followup.md)。E0主归档7441成员、逐次补充264成员的哈希记录均保留不改写。
